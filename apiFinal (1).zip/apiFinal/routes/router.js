const express = require('express')
const router = express()
const jikanController = require('../controllers/jikan-controller')
const giantbombController = require('../controllers/giantbomb-controller')

router.get('/search/anime',jikanController.searchAnime)
router.get('/search/manga',jikanController.searchManga)
router.get('/search/seasons/now', jikanController.searchSeasonsNow)
router.get('/search/animeranking', jikanController.searchAnimeRanking)
router.get('/games', giantbombController.searchGames);
router.get('/games/:id', giantbombController.getGameDetails);

module.exports = router