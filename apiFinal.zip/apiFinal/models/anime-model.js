const createAnime = (anime) => {
    return {
        title: anime.title,
        synopsis: anime.synopsis,
        image_url: anime.images?.jpg?.image_url, // Handle nested image path
        score: anime.score,
        episodes: anime.episodes,
        type: anime.type,
        url: anime.url,
    };
};

module.exports = createAnime;