const cache = require('../config/cache');
const jikan = require('../config/jikan');
const createAnime = require('../models/anime-model');

const searchAnime = async (req, res) => {
    const query = req.query.q; // The Jikan API uses 'q' for query
    if (!query) {
        return res.status(400).json({ message: 'Query parameter "q" is required' });
    }

    if (cache.has(query)) {
        console.log('Fetching data from server cache');
        return res.status(200).json(cache.get(query));
    }

    try {
        // Fetch data from Jikan API
        const response = await jikan.get('/anime', {
            params: { q: query, limit: 10 }, // Add other params if necessary
        });

        // Map response to a structured format using createAnime
        const animeResult = response.data.data.map(createAnime);

        // Cache the result
        cache.set(query, animeResult);

        // Return the formatted anime results
        return res.status(200).json(animeResult);
    } catch (error) {
        console.error('Error fetching data from Jikan API:', error.message);
        return res.status(500).json({ message: 'Failed to fetch anime data' });
    }
};

module.exports = { searchAnime };