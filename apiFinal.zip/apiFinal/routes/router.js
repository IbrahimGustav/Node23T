const express = require('express')
const router = express()
const animeController = require('../controllers/anime-controller')

router.get('/anime',animeController.searchAnime)

module.exports = router